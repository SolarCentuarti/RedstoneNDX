package cd4017be.lib.fabric;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Initial Fabric entrypoint. The original Forge initialization still needs porting. */
public final class LibFabric implements ModInitializer {
    public static final String ID = "cd4017be_lib";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    @Override
    public void onInitialize() {
        LOGGER.info("CD4017BE library Fabric port bootstrap loaded; feature registration is not yet ported.");
    }
}
