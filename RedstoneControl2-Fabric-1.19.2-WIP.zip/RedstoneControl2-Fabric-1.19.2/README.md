# Redstone Control 2 Fabric 1.19.2 — port workspace

This is an initial migration workspace assembled from the two supplied 1.16.5 source archives. Read `PORT_STATUS.md` before building: this is a port scaffold, not a finished mod. The original source trees are intentionally preserved for a careful API-by-API conversion.

Target: Minecraft 1.19.2 · Fabric Loader 0.14.25 · Fabric API 0.76.0+1.19.2 · Java 17.
