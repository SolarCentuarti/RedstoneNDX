package cd4017be.rs_ctr2.fabric;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Initial Fabric entrypoint. Redstone Control content registration is not yet ported. */
public final class RedstoneControl2Fabric implements ModInitializer {
    public static final String ID = "rs_ctr2";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Redstone Control 2 Fabric port bootstrap loaded; feature registration is not yet ported.");
    }
}
