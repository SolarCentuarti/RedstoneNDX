# Redstone Control 2 → Fabric 1.19.2 port status

## What this workspace contains
- Original CD4017BE_lib Java sources and resources (177 Java files).
- Original Redstone Control 2 Java sources and resources (120 Java files).
- A Fabric Loom multi-project Gradle layout targeting Minecraft 1.19.2, Yarn build 28, Fabric Loader 0.14.25, Fabric API 0.76.0+1.19.2, Java 17.
- Fabric metadata and minimal entrypoint bootstraps for both modules.

## Important: this is NOT a working converted mod yet
The original Java sources are preserved, not mechanically rewritten. They still contain Forge APIs and 1.16.5-era Minecraft APIs. The two bootstrap entrypoints only prove the intended Fabric structure; they do not register the original blocks, items, block entities, menus, networking, rendering, capabilities, or recipes. Do not put these placeholder JARs into a game expecting the mod to work.

## Port blockers identified
- Library: 177 Java files and 248 Forge imports (73 distinct Forge import paths).
- Mod: 120 Java files and 122 Forge imports (46 distinct Forge import paths).
- The library contains the shared event/config system, custom model/rendering hooks, network handlers, tile entities, item/fluid/energy capability wrappers, and microblock/grid systems.
- Redstone Control uses the library extensively, so the library must be ported first.
- Forge capabilities need Fabric equivalents or custom transfer interfaces (e.g. Fabric Transfer API, or explicit adapters).
- Forge event bus, registry events, config system, networking, menu opening, model data, and custom item/fluid/energy APIs need explicit Fabric rewrites.
- The original JEI and Patchouli integrations must be made optional Fabric integrations or temporarily excluded.

## Suggested order
1. Port library bootstrap, registries, config, lifecycle events, and networking.
2. Port library block entities, menus, item/fluid/energy transfer, grid and microblock APIs.
3. Port rendering/model pipeline and client-only code.
4. Port Redstone Control registries, blocks/items, block entities, recipes, advancements, and integrations.
5. Compile, launch client/server, then test saved worlds and redstone behavior.

## Build environment
Use JDK 17 and Gradle 8.6+ with network access to Fabric Maven and Maven Central. The project currently cannot compile because original Forge imports remain by design.
